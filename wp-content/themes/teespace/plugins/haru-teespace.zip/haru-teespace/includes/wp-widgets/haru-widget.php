<?php
/**
 * Abstract Haru Widget Class
 *
 * @author      HaruTheme
 * @category    Widgets
 * @package     HaruTheme/Abstracts
 * @version     1.0.0
 * @extends     WP_Widget
 */
abstract class Haru_TeeSpace_Widget extends WP_Widget {
	public $widget_cssclass;
	public $widget_description;
	public $widget_id;
	public $widget_name;
	public $settings;

	/**
	 * Constructor
	 */
	public function __construct() {
		$widget_ops = array(
			'classname'   => $this->widget_cssclass,
			'description' => $this->widget_description
		);

		parent::__construct( $this->widget_id, $this->widget_name, $widget_ops );

		add_action( 'save_post', array( $this, 'flush_widget_cache' ) );
		add_action( 'deleted_post', array( $this, 'flush_widget_cache' ) );
		add_action( 'switch_theme', array( $this, 'flush_widget_cache' ) );

	}

	/**
	 * get_cached_widget function.
	 */
	function get_cached_widget( $args ) {

		$cache = wp_cache_get( apply_filters( 'haru_cached_widget_id', $this->widget_id ), 'widget' );

		if ( ! is_array( $cache ) ) {
			$cache = array();
		}

		if ( isset( $cache[ $args['widget_id'] ] ) ) {
			echo esc_html($cache[ $args['widget_id'] ]);
			return true;
		}

		return false;
	}

	/**
	 * Cache the widget
	 * @param string $content
	 */
	public function cache_widget( $args, $content ) {
		$cache[ $args['widget_id'] ] = $content;

		wp_cache_set( apply_filters( 'haru_cached_widget_id', $this->widget_id ), $cache, 'widget' );
	}

	/**
	 * Flush the cache
	 *
	 * @return void
	 */
	public function flush_widget_cache() {
		wp_cache_delete( apply_filters( 'haru_cached_widget_id', $this->widget_id ), 'widget' );
	}

	/**
	 * Get this widgets title.
	 *
	 * @param array $instance Array of instance options.
	 * @return string
	 */
	protected function get_instance_title( $instance ) {
		if ( isset( $instance['title'] ) ) {
			return $instance['title'];
		}

		if ( isset( $this->settings, $this->settings['title'], $this->settings['title']['std'] ) ) {
			return $this->settings['title']['std'];
		}

		return '';
	}

	/**
	 * update function.
	 *
	 * @see WP_Widget->update
	 * @param array $new_instance
	 * @param array $old_instance
	 * @return array
	 */
	public function update( $new_instance, $old_instance ) {

		$instance = $old_instance;

		if ( ! $this->settings ) {
			return $instance;
		}

		foreach ( $this->settings as $key => $setting ) {

			if ( isset( $new_instance[ $key ] ) ) {
				if ( current_user_can('unfiltered_html') ) {
					$instance[$key] =  $new_instance[$key];
				}
				else {
					$instance[$key] = stripslashes( wp_filter_post_kses( addslashes($new_instance[$key]) ) );
				}
			} elseif ( 'checkbox' === $setting['type'] ) {
				$instance[ $key ] = 0;
			}
		}
		$this->flush_widget_cache();

		return $instance;
	}

	/**
	 * form function.
	 *
	 * @see WP_Widget->form
	 * @param array $instance
	 */
	public function form( $instance ) {

		if ( ! $this->settings ) {
			return;
		}

		foreach ( $this->settings as $key => $setting ) {

			$value   = isset( $instance[ $key ] ) ? $instance[ $key ] : $setting['std'];
			switch ( $setting['type'] ) {
				case "text" :
					?>
					<p>
						<label for="<?php echo esc_attr($this->get_field_id( $key )); ?>"><?php echo esc_html($setting['label']); ?></label>
						<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( $key ) ); ?>" name="<?php echo esc_attr($this->get_field_name( $key )); ?>" type="text" value="<?php echo esc_attr( $value ); ?>" />
					</p>
					<?php
					break;

				case "number" :
					$number_step = isset($setting['step']) ? $setting['step'] : '1';
					$number_min = isset($setting['min']) ? ' min="' . esc_attr($setting['min']) . '"' : '';
					$number_max = isset($setting['max']) ? ' max="' . esc_attr($setting['max']) . '"' : '';
					?>
					<p>
						<label for="<?php echo esc_attr($this->get_field_id( $key )); ?>"><?php echo esc_html($setting['label']); ?></label>
						<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( $key ) ); ?>" name="<?php echo esc_attr($this->get_field_name( $key )); ?>" type="number" step="<?php echo esc_attr( $number_step ); ?>"<?php echo sprintf('%s', $number_min); ?><?php echo sprintf('%s', $number_max); ?> value="<?php echo esc_attr( $value ); ?>" />
					</p>
					<?php
					break;

				case "select" :
				?>
				<p>
					<label for="<?php echo $this->get_field_id( $key ); ?>"><?php echo $setting['label']; ?></label>
					<select class="widefat" id="<?php echo esc_attr( $this->get_field_id( $key ) ); ?>" <?php if(isset($setting['multiple'])):?> multiple="multiple"<?php endif;?> name="<?php echo $this->get_field_name( $key ); ?><?php if(isset($setting['multiple'])):?>[]<?php endif;?>">
						<?php foreach ( $setting['options'] as $option_key => $option_value ) : ?>
							<option value="<?php echo esc_attr( $option_key ); ?>" <?php if(isset($setting['multiple']) && is_array( $value ) ): selected( in_array( (string)$option_key, $value ) , true ); else: selected( $option_key, $value ); endif; ?>><?php echo esc_html( $option_value ); ?></option>
						<?php endforeach; ?>
					</select>
				</p>
				<?php
				break;

				case "checkbox" :
					?>
					<p>
						<input id="<?php echo esc_attr( $this->get_field_id( $key ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( $key ) ); ?>" type="checkbox" value="1" <?php checked( $value, 1 ); ?> />
						<label for="<?php echo esc_attr($this->get_field_id( $key )); ?>"><?php echo esc_html($setting['label']); ?></label>
					</p>
					<?php
					break;
                case "multi-select" :
                    ?>
                    <p>
                        <label for="<?php echo esc_attr( $this->get_field_id( $key ) ); ?>"><?php echo esc_html($setting['label']); ?></label>
                        <input name="<?php echo esc_attr($this->get_field_name( $key )); ?>" type="hidden" value="<?php echo esc_attr( $value ); ?>" />
                        <select multiple class="widefat widget-select2" id="<?php echo esc_attr( $this->get_field_id( $key ) ); ?>" data-value="<?php echo esc_attr($value) ?>">
                            <?php foreach ( $setting['options'] as $option_key => $option_value ) : ?>
                                <option value="<?php echo esc_attr( $option_key ); ?>"><?php echo esc_html( $option_value ); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </p>

                    <?php
                    break;

				case "icon" :
					?>
					<div style="margin: 13px 0">
						<label for="<?php echo esc_attr($this->get_field_id( $key )); ?>"><?php echo esc_html($setting['label']); ?> </label>
						<div>
							<input style="width: 145px" type="text" class="input-icon" id="<?php echo esc_attr( $this->get_field_id( $key ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( $key ) ); ?>" value="<?php echo esc_attr($value); ?>">
							<input style="float: right"  title="<?php echo esc_html__('Click to browse icon','haru-teespace') ?>" class="browse-icon button-secondary" type="button" value="<?php echo esc_html__('Browse...','haru-teespace') ?>" />
							<span style="vertical-align: top;width: 30px; height: 30px" class="icon-preview"><i class="fa <?php echo esc_attr( $value );  ?>"></i></span>
						</div>
					</div>
					<?php
					break;
				case "image" :
					?>
					<div style="margin: 13px 0">
						<label for="<?php echo esc_attr($this->get_field_id( $key )); ?>"><?php echo esc_html($setting['label']); ?> </label>
						<div class="widget-image-field">
							<input type="text" class="input-icon" id="<?php echo esc_attr( $this->get_field_id( $key ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( $key ) ); ?>" value="<?php echo esc_attr($value); ?>">
							<button style="float: right" title="<?php echo esc_html__('Click to browse image','haru-teespace') ?>" class="browse-images button-secondary" type="button"><?php echo esc_html__('Browse...','haru-teespace') ?></button>
						</div>
						<script type="text/javascript">
							//<![CDATA[
							jQuery(document).ready(function() {
								haru_media_select("#<?php echo esc_attr( $this->get_field_id( $key ) ); ?>",'.browse-images');
							});
							//]]>
						</script>
					</div>
					<?php
					break;
				case "text-area" :
					?>
					<p>
						<label for="<?php echo esc_attr($this->get_field_id( $key )); ?>"><?php echo esc_html($setting['label']); ?></label>
						<textarea class="widefat" rows="8" cols="40" id="<?php echo esc_attr( $this->get_field_id( $key ) ); ?>" name="<?php echo esc_attr($this->get_field_name( $key )); ?>"><?php echo esc_textarea($value); ?></textarea>
					</p>
					<?php
					break;
				case "thumbnail-size" :
					global $_wp_additional_image_sizes;
					?>
					<p>
						<label for="<?php echo esc_attr($this->get_field_id( $key )); ?>"><?php echo esc_html($setting['label']); ?></label>
						<select id="<?php echo esc_attr($this->get_field_id( $key )); ?>" name="<?php echo esc_attr($this->get_field_name( $key )); ?>" class="widefat">
							<?php
							foreach ($_wp_additional_image_sizes as $size_name => $size_attr) { ?>
								<option value="<?php echo esc_attr($size_name); ?>" <?php selected($value,$size_name); ?>><?php echo ($size_name); ?></option>
							<?php	}
							?>
						</select>
					</p>
					<?php
					break;
				case "dropdown" :
					?>
					<label for="<?php echo $this->get_field_id( $key ); ?>"><?php echo $setting['label']; ?></label>
					<select class="widefat" id="<?php echo esc_attr( $this->get_field_id( $key ) ); ?>" <?php if(isset($setting['multiple'])):?> multiple="multiple"<?php endif;?> name="<?php echo $this->get_field_name( $key ); ?><?php if(isset($setting['multiple'])):?>[]<?php endif;?>">
						<?php foreach ( $setting['options'] as $option_key => $option_value ) : ?>
							<option value="<?php echo esc_attr( $option_key ); ?>" <?php if(isset($setting['multiple']) && is_array( $value ) ): selected( in_array( (string)$option_key, $value ) , true ); else: selected( $option_key, $value ); endif; ?>><?php echo esc_html( $option_value ); ?></option>
						<?php endforeach; ?>
					</select>
					<?php
					break;
				case "select2" :
					$value = isset( $value ) ? $value : $std;

					if ( ! is_array( $value ) ) {
						$value = explode( ',', $value );
					}

					wp_enqueue_script( 'select2' );
					wp_enqueue_style( 'select2' );
                    ?>
                    <label for="<?php echo esc_attr( $this->get_field_id( $key ) ); ?>"><?php echo esc_html($setting['label']); ?></label>

                    <select name="<?php echo esc_attr($this->get_field_name( $key )); ?>[]" id="<?php echo esc_attr( $this->get_field_id( $key ) ); ?>" class="widget-select2" multiple>
						<?php foreach ( $setting['options'] as $field => $option ) : ?>
							<?php
							$selected = false;
							
							if ( is_array( $value ) && in_array( $option, $value, false ) ) {
								$selected = true;
							}
							
							?>

							<option value="<?php echo esc_attr( $option ); ?>" <?php selected( true, $selected ); ?>>
								<?php echo esc_html( $field ); ?>
							</option>
						<?php endforeach; ?>
					</select>

                    <?php
                    break;
			}
		}
	}
}