/* global confirm, redux, redux_change */

!function($) {
	$(document).ready(function() {
		$("#product_attribute-select").select2();
	});
}(jQuery);